"""Narration for $0 on this computer: Kokoro-82M text-to-speech (Apache-2.0) via kokoro-onnx. No account, no API.

  scripts/py scripts/voice.py <project>          script.json -> data/narration.wav + data/lines.json (exact clip/group times)
  scripts/py scripts/voice.py --list             voices that narrate well
  scripts/py scripts/voice.py --download         only fetch the model files (~340 MB, once)

script.json: { "voice": "am_michael", "speed": 1.05, "lead": 0.45, "outro": 0.9, "gap": 0.32, "voiceover": "ai",
               "lines": [ { "text": "What if you swallow gum?", "caps": "...", "gap": 0.3 }, ... ] }
One line = one CUT, not one sentence: a sentence can run across several lines ("It slides down your throat and lands
in your stomach," / "where acid gets to work on it."). Lines are grouped into whole sentences and each sentence is
spoken in ONE pass, so the intonation flows naturally; provisional internal cuts are placed by silence/length and
then refined from real Whisper word alignment when you run words.py.
Write numbers the way they're SAID. Then run words.py for the word timings.
"""
import argparse, json, os, re, urllib.request
from pathlib import Path
import numpy as np
from scipy.io import wavfile

HOME = Path(os.environ.get('FACELESS_HOME', Path.home() / '.faceless-shorts'))
KDIR = HOME / 'kokoro'
FILES = {
    'kokoro-v1.0.onnx': 'https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx',
    'voices-v1.0.bin': 'https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin',
}
GOOD = {
    'am_michael': 'US male, steady explainer (default)', 'am_puck': 'US male, lively, playful', 'am_fenrir': 'US male, deeper',
    'am_onyx': 'US male, low', 'af_heart': 'US female, warm (best overall)', 'af_bella': 'US female, bright',
    'af_nicole': 'US female, soft and close', 'bm_george': 'UK male, documentary', 'bm_fable': 'UK male, storyteller',
    'bf_emma': 'UK female, calm',
}
SR = 24000


def ensure_models():
    KDIR.mkdir(parents=True, exist_ok=True)
    for name, url in FILES.items():
        p = KDIR / name
        if p.exists() and p.stat().st_size > 1_000_000:
            continue
        print(f'downloading {name} (once)...', flush=True)
        tmp = p.with_suffix('.part')
        urllib.request.urlretrieve(url, tmp)
        tmp.rename(p)


def trim(x, thr=0.008):
    """cut leading/trailing silence so clip start/end times are exact"""
    idx = np.where(np.abs(x) > thr)[0]
    if not len(idx):
        return x
    a = max(0, idx[0] - int(0.01 * SR))
    b = min(len(x), idx[-1] + int(0.03 * SR))
    return x[a:b]


def silences(x, thr=0.012, min_len=0.06):
    """pauses inside speech: [(start_s, end_s)] where the 10 ms RMS stays under thr for >= min_len"""
    hop = int(0.01 * SR)
    n = len(x) // hop
    if n == 0:
        return []
    rms = np.sqrt(np.mean(x[:n * hop].reshape(n, hop) ** 2, axis=1))
    quiet = rms < thr * (np.abs(x).max() + 1e-9)
    out, st = [], None
    for f, q in enumerate(quiet):
        if q and st is None:
            st = f
        if (not q or f == n - 1) and st is not None:
            if (f - st) * 0.01 >= min_len:
                out.append((st * 0.01, f * 0.01))
            st = None
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('project', nargs='?')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--download', action='store_true')
    ap.add_argument('--voice')
    ap.add_argument('--speed', type=float)
    a = ap.parse_args()
    if a.list:
        for k, v in GOOD.items():
            print(f'{k:12s} {v}')
        return
    ensure_models()
    if a.download:
        return
    if not a.project:
        ap.error('project folder missing')
    from kokoro_onnx import Kokoro
    P = Path(a.project)
    S = json.loads((P / 'script.json').read_text())
    voice = a.voice or S.get('voice', 'am_michael')
    speed = a.speed or S.get('speed', 1.0)
    k = Kokoro(str(KDIR / 'kokoro-v1.0.onnx'), str(KDIR / 'voices-v1.0.bin'))
    lang = 'en-gb' if voice.startswith('b') else 'en-us'
    say = lambda text, sp=speed: trim(np.asarray(k.create(text, voice=voice, speed=sp, lang=lang)[0], dtype=np.float64))

    cli_speed = a.speed
    groups, cur = [], []
    for i, ln in enumerate(S['lines']):
        cur.append(i)
        if re.search(r'[.?!]["\')]*$', ln['text'].strip()) or ln.get('break') or i == len(S['lines']) - 1:
            groups.append(cur)
            cur = []

    out = [np.zeros(int(S.get('lead', 0.4) * SR))]
    t = len(out[0]) / SR
    lines = [None] * len(S['lines'])
    group_meta = []
    has_internal_estimates = False

    for gi, g in enumerate(groups):
        sp = cli_speed or S['lines'][g[0]].get('speed', speed)
        x = say(' '.join(S['lines'][i]['text'] for i in g), sp=sp)
        cuts = [0.0]
        cut_sources = ['exact'] * len(g)
        if len(g) > 1:
            has_internal_estimates = True
            lens = np.array([len(say(S['lines'][i]['text'], sp=S['lines'][i].get('speed', sp))) for i in g], dtype=float)
            pauses = silences(x)
            for idx_c, c in enumerate(np.cumsum(lens)[:-1] / (lens.sum() + 1e-9) * len(x) / SR):
                near = [p for p in pauses if abs((p[0] + p[1]) / 2 - c) < 0.4]
                if near:
                    p = min(near, key=lambda p: abs((p[0] + p[1]) / 2 - c))
                    cuts.append((p[0], p[1]))
                    cut_sources[idx_c] = 'pause_snap'
                    cut_sources[idx_c + 1] = 'pause_snap'
                else:
                    cuts.append((c, c))
                    cut_sources[idx_c] = 'proportional'
                    cut_sources[idx_c + 1] = 'proportional'
        n = len(x) / SR
        group_meta.append({'group': gi, 'lines': g, 'start': round(t, 3), 'end': round(t + n, 3)})
        for j, i in enumerate(g):
            t_a = 0.0 if j == 0 else cuts[j][1]
            b = n if j == len(g) - 1 else cuts[j + 1][0]
            lines[i] = {
                'i': i,
                'text': S['lines'][i]['text'],
                'start': round(t + t_a, 3),
                'end': round(t + b, 3),
                'group': gi,
                'cut_source': cut_sources[j],
            }
            print(f'{i:2d} {lines[i]["start"]:6.2f}-{lines[i]["end"]:6.2f} [{cut_sources[j]}] {S["lines"][i]["text"]}', flush=True)
        gap = np.zeros(int(float(S['lines'][g[-1]].get('gap', S.get('gap', 0.3))) * SR))
        out += [x, gap]
        t += (len(x) + len(gap)) / SR

    outro = np.zeros(int(float(S.get('outro', 0.9)) * SR))
    out.append(outro)
    y = np.concatenate(out)
    y = y / (np.abs(y).max() + 1e-9) * 0.9
    (P / 'data').mkdir(exist_ok=True)
    wavfile.write(P / 'data/narration.wav', SR, (y * 32767).astype(np.int16))
    dur = len(y) / SR
    timing_kind = 'estimated_internal' if has_internal_estimates else 'measured'
    (P / 'data/lines.json').write_text(json.dumps({
        'duration': round(dur, 3),
        'voice': voice,
        'speed': speed,
        'voiceover': 'ai',
        'timing': timing_kind,
        'estimated': False,
        'groups': group_meta,
        'lines': lines,
    }, indent=1))
    print(f'data/narration.wav ({dur:.2f} s, {voice} x{speed}, timing={timing_kind}) + data/lines.json. Next: words.py')


if __name__ == '__main__':
    main()
