"""Word timings with local Whisper (faster-whisper small.en, MIT) -> data/words.json [{w, line, s, e}].

  scripts/py scripts/words.py <project>                       after voice.py (uses data/narration.wav + data/lines.json)
  scripts/py scripts/words.py <project> --audio my_vo.m4a      YOUR OWN recording: becomes data/narration.wav, and the
                                                               line times (data/lines.json) are rebuilt from what you said

The words keep the SCRIPT's spelling with the times Whisper heard. Words Whisper heard differently ("7" vs "seven")
or missed share the time between their matched neighbours, by length. Line start/end boundaries are derived from the
aligned words (never clamping multi-line sentences into voice.py's provisional split guesses). Also writes data/words.txt.
"""
import argparse, json, re, subprocess, sys
from difflib import SequenceMatcher
from pathlib import Path

norm = lambda w: re.sub(r'[^a-z0-9]+', '', w.lower())


def align(script_words, heard, t0, t1):
    """script_words: [str]; heard: [(word, s, e)] -> ([(s, e)], matched_count)"""
    a = [norm(w) for w in script_words]
    b = [norm(h[0]) for h in heard]
    times = [None] * len(a)
    matched = 0
    for blk in SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks():
        for k in range(blk.size):
            times[blk.a + k] = (heard[blk.b + k][1], heard[blk.b + k][2])
            matched += 1
    i = 0
    while i < len(a):
        if times[i] is not None:
            i += 1
            continue
        j = i
        while j < len(a) and times[j] is None:
            j += 1
        lo = times[i - 1][1] if i > 0 else t0
        hi = times[j][0] if j < len(a) else t1
        if hi <= lo:
            hi = lo + 0.06 * (j - i)
        L = [max(1, len(a[k])) for k in range(i, j)]
        tot = sum(L)
        c = lo
        for k, l in zip(range(i, j), L):
            d = (hi - lo) * l / tot
            times[k] = (c, c + d * 0.9)
            c += d
        i = j
    return times, matched


def validate_and_repair(words, dur_audio):
    """Ensure every word span is finite, monotonic, and non-zero; return count of repaired spans."""
    repaired = 0
    prev_s = 0.0
    for idx, w in enumerate(words):
        s = float(w['s'])
        e = float(w['e'])
        changed = False
        if s < 0 or s > dur_audio:
            s = max(0.0, min(s, dur_audio))
            changed = True
        if s < prev_s:
            s = prev_s
            changed = True
        if e <= s:
            next_s = words[idx + 1]['s'] if idx + 1 < len(words) else dur_audio
            e = min(dur_audio, max(s + 0.04, min(next_s, s + 0.12) if next_s > s else s + 0.04))
            changed = True
        if e > dur_audio:
            e = dur_audio
            if e <= s:
                s = max(0.0, e - 0.04)
            changed = True
        w['s'] = round(s, 3)
        w['e'] = round(e, 3)
        prev_s = s
        if changed:
            repaired += 1
    return repaired


def inline_fallback(P, S):
    L = json.loads((P / 'data/lines.json').read_text())
    line_rows = L['lines']
    words = []
    for i, ln in enumerate(S['lines']):
        toks = [w for w in ln['text'].split() if norm(w)]
        wts = [len(norm(w)) + 2.5 + (2.5 if w.endswith(',') else 4.5 if re.search(r'[.?!]$', w) and k < len(toks) - 1 else 0) for k, w in enumerate(toks)]
        lo, hi = line_rows[i]['start'], line_rows[i]['end']
        c = lo
        tot = sum(wts) or 1.0
        for w, wt in zip(toks, wts):
            d = (hi - lo) * wt / tot
            speak = d - (hi - lo) * (wt - len(norm(w)) - 2.5) / tot
            words.append({'w': w, 'line': i, 's': round(c, 3), 'e': round(c + max(0.04, speak * 0.92), 3)})
            c += d
    L['timing'] = 'fallback_interpolated'
    L['estimated'] = True
    (P / 'data/lines.json').write_text(json.dumps(L, indent=1))
    (P / 'data/words.json').write_text(json.dumps(words, indent=1))
    (P / 'data/words.txt').write_text('\n'.join(f"{w['s']:7.2f} {w['e']:7.2f}  L{w['line']:<2d} {w['w']}" for w in words))
    print(f'data/words.json: {len(words)} words (fallback interpolated inside line times — Whisper unavailable)')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('project')
    ap.add_argument('--audio')
    ap.add_argument('--strict', action='store_true', help='exit nonzero if Whisper match ratio < 0.60')
    a = ap.parse_args()
    P = Path(a.project)
    S = json.loads((P / 'script.json').read_text())
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel('small.en', device='cpu', compute_type='int8')
    except Exception as e:
        if a.audio or not (P / 'data/lines.json').exists():
            raise SystemExit(f'Whisper is needed for your own recording and could not load: {e}')
        print(f'Whisper unavailable ({type(e).__name__}); falling back to interpolated word spans')
        return inline_fallback(P, S)

    if a.audio:
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', a.audio, '-ac', '1', '-ar', '24000', str(P / 'data/narration.wav')], check=True)
    try:
        import numpy as np
        raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(P / 'data/narration.wav'), '-ac', '1', '-ar', '16000', '-f', 'f32le', '-'], capture_output=True, check=True).stdout
        segs, _ = model.transcribe(np.frombuffer(raw, dtype=np.float32), word_timestamps=True, vad_filter=False)
        heard = [(w.word.strip(), w.start + 0.04, w.end) for s in segs for w in s.words]
    except Exception as e:
        if a.audio or not (P / 'data/lines.json').exists():
            raise SystemExit(f'Whisper could not transcribe the recording: {e}')
        print(f'Whisper failed ({type(e).__name__}: {e}); falling back to interpolated word spans')
        return inline_fallback(P, S)

    toks = [(w, i) for i, ln in enumerate(S['lines']) for w in ln['text'].split() if norm(w)]
    dur_audio = float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', str(P / 'data/narration.wav')], capture_output=True, text=True, check=True).stdout)
    times, matched = align([w for w, _ in toks], heard, 0.0, dur_audio)
    match_ratio = matched / max(1, len(toks))
    words = [{'w': w, 'line': i, 's': round(s, 3), 'e': round(e, 3)} for (w, i), (s, e) in zip(toks, times)]

    # Bound words ONLY to their outer TTS sentence group (never to provisional internal line splits)
    has_lines = (P / 'data/lines.json').exists()
    existing_meta = json.loads((P / 'data/lines.json').read_text()) if has_lines else {}
    groups = existing_meta.get('groups') if not a.audio else None
    if groups:
        line_to_group = {li: g for g in groups for li in g['lines']}
        for w in words:
            g = line_to_group.get(w['line'])
            if g:
                w['s'] = round(min(max(w['s'], g['start']), g['end']), 3)
                w['e'] = round(min(max(w['e'], w['s']), g['end']), 3)

    repaired = validate_and_repair(words, dur_audio)

    # Derive line boundaries directly from validated word alignment
    lines = []
    for i, ln in enumerate(S['lines']):
        ws = [w for w in words if w['line'] == i]
        if ws:
            s0, e0 = ws[0]['s'], ws[-1]['e']
        else:
            prev_e = lines[-1]['end'] if lines else 0.0
            s0 = e0 = round(prev_e, 3)
        lines.append({'i': i, 'text': ln['text'], 'start': s0, 'end': e0, 'cut_source': 'aligned' if match_ratio >= 0.6 else 'low_confidence_aligned'})

    out_meta = {
        'duration': round(dur_audio, 3),
        'voiceover': 'own' if a.audio else existing_meta.get('voiceover', 'ai'),
        'timing': 'aligned',
        'estimated': False,
        'alignment': {
            'matched_words': matched,
            'total_words': len(toks),
            'heard_words': len(heard),
            'match_ratio': round(match_ratio, 3),
            'repaired_spans': repaired,
        },
        'lines': lines,
    }
    if existing_meta.get('voice'):
        out_meta['voice'] = existing_meta['voice']
    if existing_meta.get('speed'):
        out_meta['speed'] = existing_meta['speed']
    if groups:
        out_meta['groups'] = groups

    (P / 'data/lines.json').write_text(json.dumps(out_meta, indent=1))
    (P / 'data/words.json').write_text(json.dumps(words, indent=1))
    (P / 'data/words.txt').write_text('\n'.join(f"{w['s']:7.2f} {w['e']:7.2f}  L{w['line']:<2d} {w['w']}" for w in words))
    print(f'data/words.json: {len(words)} words (Whisper heard {len(heard)}, matched {matched}/{len(toks)} = {match_ratio:.1%}, repaired={repaired})')
    if match_ratio < 0.75:
        print(f'WARNING: low Whisper alignment match ratio ({match_ratio:.1%}); inspect data/words.txt', file=sys.stderr)
        if a.strict and match_ratio < 0.60:
            raise SystemExit(1)


if __name__ == '__main__':
    main()
