"""Estimated timing with NO voice: script.json -> data/lines.json + data/words.json.

  scripts/py scripts/estimate.py <project> [--wps 2.8] [--mode captions-only|preview]

Use it for a captions-only video (the user records the voiceover later, to the captions), or to preview a cut
before the real voice exists. Each word gets a length from its letters; commas and mid-line full stops add pauses.
When the real narration is ready, voice.py + words.py overwrite both files and everything re-times itself.
Only the Python standard library is needed.
"""
import argparse, json, re
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('project')
ap.add_argument('--wps', type=float, default=2.8, help='speaking rate in words per second (Kokoro am_michael at 1.05 is ~2.8)')
ap.add_argument('--mode', choices=['captions-only', 'preview'], default=None, help='explicit voiceover mode recorded in data/lines.json')
a = ap.parse_args()
P = Path(a.project)
S = json.loads((P / 'script.json').read_text())
mode = a.mode or ('captions-only' if S.get('voiceover') == 'captions-only' else 'captions-only')
speed = S.get('speed', 1.0)
t = float(S.get('lead', 0.4))
lines, words = [], []
for i, ln in enumerate(S['lines']):
    toks = ln['text'].split()
    letters = [len(re.sub(r'[^A-Za-z0-9]', '', w)) or 1 for w in toks]
    base = len(toks) / (a.wps * speed)
    unit = base / max(1.0, sum(l + 2.5 for l in letters))
    start = t
    for w, l in zip(toks, letters):
        d = (l + 2.5) * unit
        words.append({'w': w, 'line': i, 's': round(t, 3), 'e': round(t + max(0.04, d * 0.92), 3)})
        t += d
        if w.endswith(','):
            t += 0.16
        elif re.search(r'[.?!]$', w) and w is not toks[-1]:
            t += 0.32
    lines.append({'i': i, 'text': ln['text'], 'start': round(start, 3), 'end': round(t, 3), 'cut_source': 'estimated'})
    t += float(ln.get('gap', S.get('gap', 0.32)))
dur = lines[-1]['end'] + float(S.get('outro', 0.9))
(P / 'data').mkdir(exist_ok=True)
(P / 'data/lines.json').write_text(json.dumps({
    'duration': round(dur, 3),
    'estimated': True,
    'timing': 'estimated',
    'voiceover': mode,
    'lines': lines,
}, indent=1))
(P / 'data/words.json').write_text(json.dumps(words, indent=1))
if (P / 'data/narration.wav').exists() and mode == 'captions-only':
    print('NOTE: data/narration.wav exists on disk; tools/mix.py will ignore it because voiceover=captions-only.')
print(f'estimated timing ({mode}): {len(lines)} lines, {len(words)} words, {dur:.2f} s -> data/lines.json, data/words.json')
