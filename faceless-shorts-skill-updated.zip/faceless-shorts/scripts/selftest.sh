#!/bin/bash
# Proves the pipeline on this computer: verifies canonical capture.mjs sync across styles, then builds every style's
# example in an isolated temporary directory (voice -> words -> check -> cues -> mix -> contact sheet -> 4 s clip).
#   bash selftest.sh              all styles
#   bash selftest.sh --no-voice   skip Kokoro/Whisper (estimated timing)
set -u
SKILL="$(cd "$(dirname "$0")/.." && pwd)"; PY="$SKILL/scripts/py"
T="$(mktemp -d "${TMPDIR:-/tmp}/faceless-selftest-XXXXXX")"; LOG="$T/selftest.log"; : > "$LOG"
VOICE=1; [ "${1:-}" = "--no-voice" ] && VOICE=0
fail=0; note() { printf '%-22s %s\n' "$1" "$2"; }

for d in "$SKILL"/styles/*/; do
  s=$(basename "$d")
  if ! cmp -s "$SKILL/scripts/capture.mjs" "$d/example/tools/capture.mjs"; then
    note "$s" "FAILED: example/tools/capture.mjs differs from scripts/capture.mjs"
    fail=1
  fi
done

for d in "$SKILL"/styles/*/; do
  s=$(basename "$d"); P="$T/$s"; t1=$(date +%s)
  bash "$SKILL/scripts/new_video.sh" "$s" "$s" --dir "$T" >> "$LOG" 2>&1 || { note "$s" "FAILED to create (see $LOG)"; fail=1; continue; }
  (
    cd "$P" || exit 1; echo "== $s"
    if [ $VOICE = 1 ]; then "$PY" "$SKILL/scripts/voice.py" . && "$PY" "$SKILL/scripts/words.py" . || exit 1
    else "$PY" "$SKILL/scripts/estimate.py" . --mode captions-only || exit 1; fi
    node tools/capture.mjs check | tee review/check.txt; [ "${PIPESTATUS[0]}" -eq 0 ] || exit 1
    grep -q "CHECK OK" review/check.txt || exit 1
    node tools/capture.mjs cues && "$PY" tools/mix.py . || exit 1
    node tools/capture.mjs sheet review/all.jpg 1 8 || exit 1
    node tools/capture.mjs video renders/selftest.mp4 2 6 --draft || exit 1
  ) >> "$LOG" 2>&1
  M="$P/renders/selftest.mp4"
  if [ -f "$M" ]; then
    A=$(ffmpeg -v info -i "$M" -af volumedetect -vn -f null - 2>&1 | awk '/mean_volume/ {printf "%d", $5}')
    if [ "${A:--99}" -gt -50 ]; then note "$s" "ok, $(( $(date +%s) - t1 )) s · sheet: $P/review/all.jpg · clip: $M"; else note "$s" "FAILED: clip is silent ($A dB)"; fail=1; fi
  else note "$s" "FAILED (see $LOG)"; fail=1; fi
done
[ $fail = 0 ] && echo "SELFTEST PASSED ($T)" || { echo "SELFTEST FAILED. Full log: $LOG"; exit 1; }
