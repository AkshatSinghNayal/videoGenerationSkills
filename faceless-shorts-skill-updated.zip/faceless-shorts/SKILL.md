---
name: faceless-shorts
description: Make narrated faceless YouTube Shorts / TikToks / Reels fully in code on the user's computer, with a free local AI voice and word-synced captions, $0. Six styles - Deep Dive 3D (Zack D. Films-like 3D "what happens if" body/science explainers), Night File 3D (unsolved mysteries, true crime), Inside Out (flat 2D x-ray explainers), Stick Story (stick-figure "what would you do if" survival steps), Paper Atlas (history in cut paper with maps), Tall Tale 3D (funny true stories and fictional dark-comedy shorts with flat 2D cartoon people in a 3D world). Use whenever someone wants a faceless short, a what-if or what-happens-if explainer, a Zack D. Films style video, a mystery or true-crime short, a stick-figure story, a history short, a funny true story, a fictional comedy/dark-comedy storytime short, or a video in one of these styles, even from just a topic or a writer handoff prompt.
---

# Faceless Shorts

You make a finished vertical or square short (up to 3 minutes / 179 s) from a topic or an approved writer handoff: script, voice, word-synced captions, animated shots, sound and music, rendered to MP4. **Everything is code**: canvas drawing, headless Chrome capture, ffmpeg, a local Kokoro voice, local Whisper word timing, numpy sound. No AI images or video, no API keys, no credits.
`SKILL` = the folder this file is in. Projects live in `~/faceless-shorts/<short-name>/` (or `--dir <parent>`).

| style | what it makes | length · aspect |
|---|---|---|
| **Deep Dive 3D** `deep-dive` | the flagship, Zack D. Films-like: sculpted 3D people in sunlit sets, glowing x-ray bodies, camera journeys through blood vessels, shallow focus. "What happens if…?" body and science | 30-45 s (up to 179 s) · 9:16 |
| **Night File 3D** `night-file` | unsolved mysteries / true crime: dark 3D places with one light, faceless people (the subject glows red), typewriter dates, case-file inserts | 30-45 s (up to 179 s) · 9:16 |
| **Inside Out** `inside-out` | flat 2D "What happens if…?" explainer: a simple hero, x-ray cutaways, bold 1-3 word captions, punchy cuts | 25-40 s (up to 179 s) · 9:16 |
| **Stick Story** `stick-story` | "What would you do if…?" survival steps: stick people with acting eyes, flat rooms day/night, gold step cards | 30-45 s (up to 179 s) · 9:16 |
| **Paper Atlas** `paper-atlas` | history in cut paper: parchment maps, crimson routes, gold date ribbons, period figures | 30-45 s (up to 179 s) · 9:16 |
| **Tall Tale 3D** `tall-tale` | funny stories & adult dark-comedy satire: flat 2D cartoon people (big round heads, ink outlines) acting in a 3D world, camera moving, expressive reactions | 40-179 s · 9:16 |

Which style: body / health / science "what happens if" → **Deep Dive 3D** (or **Inside Out** for a lighter, faster 2D look) · creepy, unexplained, true crime, "this happened in 1971" → **Night File 3D** · survival, life hacks, "here's what you do" → **Stick Story** · a historical event, "how X happened" → **Paper Atlas** · a funny true story or fictional dark-comedy storytime → **Tall Tale 3D**. If it isn't obvious, ask once.

Each style = `styles/<style>/style-sheet.png` (the look in one image, drawn by the style's own code) + `STYLE.md` (the authoritative rules for that style's captions, palette, and layout + engine manual) + `example/` (a complete project that renders as-is). **Read the style's STYLE.md in full before planning.**

## 0. First use on a computer
`bash SKILL/scripts/setup.sh` until it prints **All set** (checks Node 22+, ffmpeg/ffprobe, Chrome; builds `~/.faceless-shorts/venv` with pinned compatible dependencies; downloads the Kokoro voice ~340 MB and Whisper small.en ~0.5 GB). Install anything missing the free, official way, and ask before anything that needs a password. Then `bash SKILL/scripts/selftest.sh` must print **SELFTEST PASSED**: open the contact sheet and clip it names and look at them.

## 1. Intake & Writer Handoff
If the user provides an approved production prompt / locked script (for example from `dark-comedy-shorts-writer`):
- **Respect the writer handoff:** The writer owns the approved narration, callbacks, roast/UI cards, character expressions, and intentional comedy pauses. **Do not rewrite, shorten, or "improve" locked narration.**
- **Fictional stories & duration:** Fictional stories are fully supported across 45–179 seconds without fabricating `"sources"` (only factual/true-story claims need `"sources"` in `script.json`).
- **Cards vs. spoken captions:** Keep independent UI/roast cards separate from spoken narration—never send UI card text to Kokoro, keep card text concise with enough hold time to read comfortably on mobile, and never let cards collide with spoken captions or faces.

Otherwise (starting from a topic alone), ask only what's unknown in one message: topic (or "you pick 3 ideas"), a link to a short whose format they like (optional), length (default ~30 s), voice (`SKILL/scripts/py SKILL/scripts/voice.py --list`; default `am_michael`), voiceover mode (`"ai"` default · `"own"` recording via `words.py --audio` · `"captions-only"` via `estimate.py`), music (built-in bed · none · royalty-free file), end line / handle. "Just go" = the defaults.

## 2. The plan (when starting from a topic)
Show: title · the full narration, one line per cut, with its caption chunks · the shot list, one line each (what we see, what moves, which word it lands on) · new components you'll add to the kit, if any · facts and their sources (when making factual claims). Ask **"Build it?"** and wait. (Skip approval wait if the user already gave an explicit "just go" or a complete locked production prompt.)

**Script rules (when writing original copy).** Write the way a person actually talks to a friend: full, flowing sentences with connecting words ("Well,", "where", "but", "so", "which means"), not a list of short caption-like statements.
**A line is a CUT, not a sentence**: split each sentence into 1-3 lines at natural pauses (commas, "and", "where"), so the picture changes every 1.5-3.5 s while the voice keeps flowing (`voice.py` speaks each whole sentence in one pass unless `"break": true` is set, and `words.py` derives line boundaries from aligned words).
Write numbers as they're said ("seven"). Original writing only: take a format you like, never another creator's script or shots. Factual health/history claims must be checked against reliable sources (listed in `script.json` `"sources"`); fictional comedy does not need fake sources.

## 3. Build
1. `bash SKILL/scripts/new_video.sh <style> <short-name> [--dir <parent>]` creates the self-contained project (and copies the canonical `scripts/capture.mjs` into `tools/capture.mjs`).
2. Write `script.json` (`voice`, `speed`, `"voiceover": "ai" | "own" | "captions-only"`, `"seed": 1337`, `lines` + `caps` + `gap`).
3. Timing:
   - `"ai"`: `SKILL/scripts/py SKILL/scripts/voice.py <proj>` then `SKILL/scripts/py SKILL/scripts/words.py <proj>`. Inspect `data/lines.json` (`timing: "aligned"`, `alignment.match_ratio`) and `data/words.txt`. Never present `"estimated"` or `"fallback_interpolated"` timing as exact measured sync.
   - `"own"`: `SKILL/scripts/py SKILL/scripts/words.py <proj> --audio their.m4a`.
   - `"captions-only"`: `SKILL/scripts/py SKILL/scripts/estimate.py <proj> --mode captions-only`. `mix.py` obeys `voiceover: "captions-only"` and will ignore any stale `data/narration.wav` on disk.
4. Rewrite `src/shots.js`: place shots with `cut(i)` and key reveals on words with `Wd('word', line)`. Reuse the kit (`src/core/kit.js` / `toon.js` / `world.js`); keep procedural randomness deterministic via `seed` in `script.json` (`lib.js` `makeRng` / `rand()`).
5. In the project: `node tools/capture.mjs check` (must exit 0 and print `CHECK OK`) → `node tools/capture.mjs cues` → `SKILL/scripts/py tools/mix.py .` → QA (section 4) → `node tools/capture.mjs video renders/<name>.mp4` (verifies FFmpeg exit status and output streams via `ffprobe`).
   Iterating on one shot: `node tools/capture.mjs frames review/f "4.2,4.6"` and look.

## 4. QA: never show a frame you haven't looked at
`node tools/capture.mjs sheet review/all.jpg 0.5 10` (a frame every 0.5 s, time-stamped) and read the whole sheet, then key frames full size. For every frame ask:
- **Does it make sense?** Maintain visual mode consistency per shot, keep props attached to hands, and never reveal a visual effect or punchline before its cause/word.
- **Does it match the narration at that moment?** Picture changes just before its line; reveals land on their word.
- **Is anything colliding?** Moving characters, props, labels, pills, UI roast cards, and captions never collide or clip out of frame.
- **Style-authoritative captions & palette:** Follow the chosen style's `STYLE.md` (and any explicit user/writer prompt override) for caption word count, font, highlight color (e.g., yellow in Inside Out/Deep Dive, red in Night File, crimson in Paper Atlas, none or explicit comedy highlight in Tall Tale), layout zones, and color palette. Ensure readable UI card holds on mobile.
- **Sound:** Voice clear over music; effects balanced; silence windows honored.
Fix, re-render the sheet, re-check. Tell the user what you caught and fixed.

## 5. Deliver
Verify the exported MP4 is non-empty, decodable, and has expected streams/duration, then open it for the user. Also give: a share copy if > 35 MB (`ffmpeg -i in.mp4 -c:v libx264 -crf 21 -preset slow -c:a aac -b:a 160k -movflags +faststart share.mp4`), the best cover frame or thumbnail, a title, a description, and 5-8 hashtags.
For own-recording mode, also give them the script with each line's timing to read against. Offer one round of precise changes and re-render only what changed.

## 5b. Publish to YouTube (only when the user asks to upload)
Do not assume hardcoded Zapier action names or temp file hosts exist in the current environment.
1. **Discover tools first:** Inspect the tools/integrations actually available in the session (e.g., YouTube API/MCP/Zapier actions). If no upload integration is available or connected, report the gap clearly and provide the local MP4 + metadata for manual upload.
2. **Confirm before writing:** Never upload without explicit user confirmation of target channel, title, visibility (`private` / `unlisted` / `public`), and category (e.g. Comedy = 23, Education = 27). If a temp public URL is required by an integration, disclose that first and verify the hosted URL (`curl -sSI <url>` returns 200/206 video content-type) before uploading.
3. **Shorts compatibility:** Current YouTube Shorts supports **vertical or square videos up to 3 minutes (180 s)**. Include `#Shorts` in the description/tags as appropriate, and report the returned video URL cleanly.

## Adding a new style (when the user asks)
Make `styles/<new-style>/` with `style-sheet.png`, `STYLE.md` (look rules, palette, format, engine/kit map, components, shot anatomy, cue types, QA pitfalls) and a complete `example/`. Copy `scripts/capture.mjs` to `example/tools/capture.mjs` (or run `new_video.sh`), and add the new style to the table above. Run `selftest.sh` until every style passes.

## 3D styles (Deep Dive, Night File, Tall Tale)
They render real 3D with three.js in headless Chrome. With a graphics card it's fast and full quality (on Linux, `tools/capture.mjs` automatically uses `--enable-gpu --use-gl=angle --use-angle=gl`). Without a GPU (a laptop without GPU acceleration, a cloud sandbox), render with `SOFTWARE_GL=1 QS='&res=0.6&aa=0&shadow=1024' FPS=24` in front of **every** `node tools/capture.mjs ...` command (`check`, `frames`, `sheet`, `video`) so SwiftShader stays fast (≈2 s per frame; tell the user the render time up front, run it in the background, and QA with `sheet review/all.jpg 1 10` first). Their STYLE.md files list the 3D API.

## Never
Generate images or video with AI; spend the user's money or credits; upload to YouTube or any host without the user asking and confirming; copy another creator's script, shots or frames; rewrite a writer-locked script without approval; overwrite a user's project without asking; ship a frame you haven't looked at; claim full pipeline validation from syntax checks alone.
