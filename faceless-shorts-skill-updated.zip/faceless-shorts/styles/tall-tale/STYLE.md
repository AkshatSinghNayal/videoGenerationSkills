# Tall Tale 3D: funny stories & adult dark comedy, 9:16

Playful, clever, sarcastic. Flat 2D cartoon people (thick ink outlines, big round white heads, bean bodies, stick
limbs — never fully modeled 3D humans) acting inside a colourful 3D world: small-town streets, apartments, offices, meadows, trains.
The camera moves smoothly in every shot, faces react on every beat, and optional UI/roast cards add a second visual joke.
Example: `example/` = **THE GIRL WHO WAS MAILED TO GRANDMA** (1914; 52 s, 21 shots). Sheet: `style-sheet.png`.

## 1. Rules
- **People are 2D cutouts, the world is 3D.** Every person is a `Toon` cut-out that turns to face the camera and casts a real
  shadow. Never claim `Toon` is a fully modeled 3D human; never draw 3D sets flat.
- **Faces do the acting.** Change the mood on the beat: `smug` when someone's clever, `shock` on the reveal, `laugh` /
  `happy` for the payoff, `worried` + `sweat` for trouble, `tired` / `hollow` for deadpan exhaustion. Blink with `blink(t)`, talk with `talk(t)`.
- Consistent character silhouettes/outfits all video. Kids: `kid: true` (short legs) and `height: 1.4`.
- Camera always moving: controlled push-ins, pans, crane-downs, a punch-in on the reveal word. New shot on every cut (typically 1.5-3.5 s).
- Bright midday sun outside, warm bulbs inside, pink sunset for endings or flashbacks.
- Captions: Inter Black with thick black outline and soft shadow, centre screen (y 1340–1360), 1–3 words per chunk. Default Tall Tale uses plain white captions (no colour highlight); when a writer prompt explicitly asks for yellow `*word` highlights, enable `*` highlighting in `src/core/captions.js`.
- **True stories vs. fictional dark comedy:**
  - True-story shorts (typically 40–60 s): check every fact against reliable sources and list them in `script.json` `"sources"`.
  - Fictional comedy / writer handoff (45–179 s): follow the writer's locked narration, callbacks, roast cards, character expressions, and comedy pauses without rewriting them or inventing fake `"sources"`. Keep UI roast cards separate from spoken narration and hold them long enough to read on mobile.
- Narration: `am_michael` (speed ~1.05–1.10, or per-beat speeds from the delivery manifest). Music `"bounce"` (light comedy) with comedic silence windows where specified. Lots of small sounds: `pop`, `plop`, `boing`, `stamp`, `ding`, `chirp`, `chug`, `whoosh` on cuts.

## 2. Engine map (`example/src/`)
| file | gives you |
|---|---|
| `core/engine.js` | `makeEngine` (neutral tone curve, soft shadows, bloom, depth of field, saturation grade), `camera(fov)` |
| `core/toon.js` | `drawToon(g, look, st)` (2D drawing), `new Toon(look, { height, res })` (3D cut-out: `.at(x,y,z)`, `.set(st)`, `.face(cam)`, `.tint(col)`, `.restyle(patch)`), `PROPS` held in hands |
| `core/world.js` | sets: `mainStreet(E, { shops, dusk })` (returns `buildings` with each shop's position), `interior(E, { wall, motif, floor, ceiling, view, signText, counterOn })`, `meadow(E, { sunset, fenceOn })`; pieces: `sky, clouds, sunlight, hills, tree, pole, wire, lamp, barrel, crate, car, fence, bunting, signBoard, facade, extras`; painted textures `T.planks/wallpaper/brick/siding/dirt/grass/felt`; `snapshot(E, scene, cam)` renders a set into a texture (window views) |
| `core/props.js` | `house()` (`.door` opens), `signpost`, `platformScale()` (`.set(lbs)`), `train()` (`.update(t)`), `rails`, `cubbies`, `mailSack`, `parcel`, `desk`, `poster(lines)`, `chickCrate()` |
| `core/captions.js` | one-word captions, `captionText(text, x, y)` |

**Toon look**: `{ body, pattern: plain│check│stripes│overalls│vest│apron│stamps, patCol, hat: none│cap│bowler│boater│beanie│visor│tophat│bun│flower│bow│mailcap, hatCol, band, neck: none│bowtie│tie│scarf│collar, neckCol, dots, extra: [mustache, glasses, freckles, blush, pencil, monocle], kid, stamps }`.
**Toon state**: `{ mood: neutral│smug│happy│laugh│shock│worried│angry│sad│sly│proud│tired│dizzy, look: [dx, dy], blink, talk,
sweat, tears, armL / armR: [shoulder°, elbow°] (0 = down, 150 = up), legs: stand│walk│run│sit│jump, phase, lean, bob,
holdL / holdR: PROPS.x, flip }`. A prop made with arguments (`PROPS.book('RULES', 1)`) needs a `v: 'something'` in the
state that changes when the prop changes, so the cut-out redraws.
Positions: people stand at y 0 (boardwalks y 0.18, on a counter y 1.26). Interior counter: x 2.2..3.2, clerk at x 3.55.

## 3. Shot anatomy (see `example/src/shots.js`)
Build every set once at the top, give each set its own cut-outs, then per shot: place people, `set()` their state from
`t`, `shoot(scene, people, camFrom, camTo, lookFrom, lookTo, k, LOOK)` (moves the camera, turns everyone to face it,
renders with depth of field), `blit()`, then any 2D overlay (a RETURN TO SENDER stamp). Cues go on the word
(`cue(Wd('banned', 17), 'stamp')`).

## 4. QA pitfalls
- A cut-out seen from the side becomes a sliver: keep the camera within ~60° of facing people (`.face(cam)` handles the rest).
- People inside furniture: check feet heights (boardwalk 0.18, counter top 1.18 + scale 0.08).
- Shadows only fall inside the sun's shadow box: move `sun.key.target` near the action when you build a new set.
- Rendering speed: same as Deep Dive (`SOFTWARE_GL=1 QS='&res=0.6&aa=0&shadow=1024' FPS=24` without a GPU, ≈2-3 s/frame).
